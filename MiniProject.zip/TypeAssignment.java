package MiniProject;

public enum TypeAssignment {
     HOMEWORK,
    PROJECT
}
